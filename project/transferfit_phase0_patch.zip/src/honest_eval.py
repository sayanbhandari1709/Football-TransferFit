"""TRANSFERFIT - honest evaluation harness (Phase 0).

Purpose
-------
Every number reported in the paper must come from a model that never saw the
rows it is scored on. This module provides:

* baselines (base rate, market value only, minutes only, start-ratio only)
  so any model has to *beat something simple*;
* the existing LR / RF / GBM models plus a small MLP ablation, all fit on the
  training split only (peer features for variant D are recomputed inside each
  split, exactly as in ``model.run_variant``);
* two protocols
    1. time split  : train post_season <= 2024, test post_season == 2025
    2. grouped CV  : repeated StratifiedGroupKFold by player_id
       (NOT temporal - reported as a secondary, optimistic protocol);
* bootstrap 95% CIs (resampling test rows) for AUC, Brier, log loss, ECE;
* paired bootstrap of AUC differences against a reference model.

Nothing here modifies model.py / similarity.py / adaptation_label.py.
"""
from __future__ import annotations

import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from src.model import build_X, make_pipeline, time_split
from src.similarity import compute_peer_features

warnings.filterwarnings("ignore")

EPS = 1e-6


# --------------------------------------------------------------------------
# metrics
# --------------------------------------------------------------------------
def ece(y: np.ndarray, p: np.ndarray, bins: int = 5) -> float:
    """Expected calibration error with equal-width bins (few bins: n is small)."""
    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1]), 0, bins - 1)
    total = 0.0
    for b in range(bins):
        m = idx == b
        if m.any():
            total += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(total)


def point_metrics(y: np.ndarray, p: np.ndarray) -> dict:
    p = np.clip(p, EPS, 1 - EPS)
    return {
        "auc": roc_auc_score(y, p) if len(np.unique(y)) > 1 else np.nan,
        "brier": brier_score_loss(y, p),
        "log_loss": log_loss(y, p, labels=[0, 1]),
        "ece": ece(y, p),
    }


def bootstrap_ci(y: np.ndarray, p: np.ndarray, n_boot: int = 2000, seed: int = 0) -> dict:
    """95% percentile CI for each metric, resampling test rows."""
    rng = np.random.default_rng(seed)
    n = len(y)
    acc = {k: [] for k in ("auc", "brier", "log_loss", "ece")}
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        if len(np.unique(y[i])) < 2:
            continue
        m = point_metrics(y[i], p[i])
        for k in acc:
            acc[k].append(m[k])
    out = {}
    for k, v in acc.items():
        lo, hi = np.percentile(v, [2.5, 97.5])
        out[f"{k}_lo"], out[f"{k}_hi"] = float(lo), float(hi)
    return out


def paired_auc_diff(y: np.ndarray, p_a: np.ndarray, p_b: np.ndarray,
                    n_boot: int = 2000, seed: int = 0) -> dict:
    """AUC(a) - AUC(b) with a paired bootstrap over test rows."""
    rng = np.random.default_rng(seed)
    n = len(y)
    diffs = []
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        if len(np.unique(y[i])) < 2:
            continue
        diffs.append(roc_auc_score(y[i], p_a[i]) - roc_auc_score(y[i], p_b[i]))
    diffs = np.asarray(diffs)
    return {
        "delta_auc": float(roc_auc_score(y, p_a) - roc_auc_score(y, p_b)),
        "delta_lo": float(np.percentile(diffs, 2.5)),
        "delta_hi": float(np.percentile(diffs, 97.5)),
        "p_a_better": float((diffs > 0).mean()),
    }


# --------------------------------------------------------------------------
# model registry
# --------------------------------------------------------------------------
def _single_feature_pipeline(C: float = 1.0) -> Pipeline:
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("model", LogisticRegression(C=C, max_iter=4000)),
    ])


def _mlp_pipeline(seed: int) -> Pipeline:
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("model", MLPClassifier(hidden_layer_sizes=(16,), alpha=0.1,
                                max_iter=2000, random_state=seed)),
    ])


# name -> (kind, spec)
#   kind "const"  : base rate
#   kind "single" : LR on a few named columns (log1p applied to market value)
#   kind "sk"     : (variant, algorithm) using model.make_pipeline
#   kind "lr_reg" : (variant, C) LR with stronger regularisation
#   kind "mlp"    : (variant,) small MLP ensemble (5 seeds, probabilities averaged)
MODELS = {
    "base_rate": ("const", None),
    "mv_only": ("single", ["pre_market_value"]),
    "minutes_only": ("single", ["pre_minutes"]),
    "start_ratio_only": ("single", ["pre_start_ratio"]),
    "lr_A": ("sk", ("A", "lr")),
    "lr_B": ("sk", ("B", "lr")),
    "lr_C": ("sk", ("C", "lr")),
    "lr_D": ("sk", ("D", "lr")),          # current production configuration
    "lr_C_reg": ("lr_reg", ("C", 0.05)),
    "rf_C": ("sk", ("C", "rf")),
    "gbm_C": ("sk", ("C", "gbm")),
    "mlp_C": ("mlp", ("C",)),
}

REFERENCE = "mv_only"


def _fit_predict(name: str, train: pd.DataFrame, test: pd.DataFrame) -> np.ndarray:
    kind, spec = MODELS[name]
    ytr = train["label"].astype(int).to_numpy()

    if kind == "const":
        return np.full(len(test), ytr.mean())

    if kind == "single":
        def col(df):
            X = df[spec].apply(pd.to_numeric, errors="coerce").copy()
            if "pre_market_value" in X:
                X["pre_market_value"] = np.log1p(X["pre_market_value"])
            return X
        pipe = _single_feature_pipeline().fit(col(train), ytr)
        return pipe.predict_proba(col(test))[:, 1]

    variant = spec[0]
    tr, te = train.copy(), test.copy()
    if variant == "D":
        tr, te = compute_peer_features(tr, te)
    Xtr = build_X(tr, variant)
    Xte = build_X(te, variant).reindex(columns=Xtr.columns, fill_value=0.0)

    if kind == "sk":
        pipe = make_pipeline(spec[1]).fit(Xtr, ytr)
        return pipe.predict_proba(Xte)[:, 1]
    if kind == "lr_reg":
        pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(C=spec[1], max_iter=4000,
                                         class_weight="balanced")),
        ]).fit(Xtr, ytr)
        return pipe.predict_proba(Xte)[:, 1]
    if kind == "mlp":
        ps = [_mlp_pipeline(s).fit(Xtr, ytr).predict_proba(Xte)[:, 1] for s in range(5)]
        return np.mean(ps, axis=0)
    raise ValueError(name)


def predict_all(train: pd.DataFrame, test: pd.DataFrame, names=None) -> pd.DataFrame:
    """Fit every model on ``train`` only and return test-set probabilities."""
    names = names or list(MODELS)
    out = test[["player_name", "source_team_name", "target_team_name",
                "post_season", "label"]].copy().reset_index(drop=True)
    for n in names:
        out[n] = _fit_predict(n, train.reset_index(drop=True), test.reset_index(drop=True))
    return out


# --------------------------------------------------------------------------
# protocol 1: time split
# --------------------------------------------------------------------------
def evaluate_time_split(df: pd.DataFrame, n_boot: int = 2000):
    train, test = time_split(df)
    preds = predict_all(train, test)
    y = preds["label"].to_numpy().astype(int)
    rows, paired = [], []
    for n in MODELS:
        p = preds[n].to_numpy()
        row = {"model": n, "train_n": len(train), "test_n": len(test),
               "test_pos_rate": float(y.mean())}
        row.update(point_metrics(y, p))
        row.update(bootstrap_ci(y, p, n_boot=n_boot))
        rows.append(row)
        if n != REFERENCE:
            d = paired_auc_diff(y, p, preds[REFERENCE].to_numpy(), n_boot=n_boot)
            paired.append({"model": n, "reference": REFERENCE, **d})
    return preds, pd.DataFrame(rows), pd.DataFrame(paired)


# --------------------------------------------------------------------------
# protocol 2: repeated grouped CV (player_id never split across folds)
# --------------------------------------------------------------------------
def evaluate_grouped_cv(df: pd.DataFrame, n_splits: int = 5, n_repeats: int = 5,
                        names=None) -> pd.DataFrame:
    names = names or list(MODELS)
    df = df.reset_index(drop=True)
    y = df["label"].astype(int).to_numpy()
    groups = df["player_id"].to_numpy()
    recs = []
    for r in range(n_repeats):
        cv = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=r)
        oof = {n: np.zeros(len(df)) for n in names}
        for tr_i, te_i in cv.split(df, y, groups):
            tr, te = df.iloc[tr_i], df.iloc[te_i]
            for n in names:
                oof[n][te_i] = _fit_predict(n, tr, te)
        for n in names:
            m = point_metrics(y, oof[n])
            recs.append({"repeat": r, "model": n, **m})
    per = pd.DataFrame(recs)
    agg = per.groupby("model").agg(
        auc_mean=("auc", "mean"), auc_sd=("auc", "std"),
        brier_mean=("brier", "mean"), log_loss_mean=("log_loss", "mean"),
        ece_mean=("ece", "mean")).reset_index()
    return agg.set_index("model").loc[names].reset_index()


# --------------------------------------------------------------------------
# reliability figure
# --------------------------------------------------------------------------
def reliability_figure(preds: pd.DataFrame, models, path: Path, bins: int = 5):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    y = preds["label"].to_numpy().astype(int)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.3))
    axes[0].plot([0, 1], [0, 1], "--", color="grey")
    edges = np.linspace(0, 1, bins + 1)
    for n in models:
        p = preds[n].to_numpy()
        idx = np.clip(np.digitize(p, edges[1:-1]), 0, bins - 1)
        xs, ys = [], []
        for b in range(bins):
            m = idx == b
            if m.sum() >= 3:
                xs.append(p[m].mean()); ys.append(y[m].mean())
        axes[0].plot(xs, ys, "o-", label=n)
    axes[0].set_xlabel("Mean predicted probability")
    axes[0].set_ylabel("Observed adaptation rate")
    axes[0].set_title("Reliability - held-out 2024/25 transfers")
    axes[0].legend(fontsize=8)
    for n in models:
        axes[1].hist(preds[n], bins=15, alpha=0.5, label=n)
    axes[1].set_title("Predicted probabilities")
    axes[1].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


# --------------------------------------------------------------------------
# one-call entry point
# --------------------------------------------------------------------------
def run_all(df: pd.DataFrame, tables_dir: Path, figures_dir: Path,
            n_boot: int = 2000, n_repeats: int = 5, do_cv: bool = True):
    tables_dir, figures_dir = Path(tables_dir), Path(figures_dir)
    preds, ts, paired = evaluate_time_split(df, n_boot=n_boot)
    preds.to_csv(tables_dir / "time_split_test_predictions.csv", index=False)
    ts.to_csv(tables_dir / "honest_eval_time_split.csv", index=False)
    paired.to_csv(tables_dir / "honest_eval_paired_vs_baseline.csv", index=False)
    reliability_figure(preds, ["base_rate", "lr_D", "lr_C_reg"],
                       figures_dir / "honest_reliability.png")
    cv = None
    if do_cv:
        cv = evaluate_grouped_cv(df, n_repeats=n_repeats)
        cv.to_csv(tables_dir / "honest_eval_grouped_cv.csv", index=False)
    return preds, ts, paired, cv
