"""Run the leakage-safe evaluation (Phase 0).

    python scripts/run_honest_eval.py            # full run incl. grouped CV
    python scripts/run_honest_eval.py --fast     # time split only, fewer bootstraps
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))

from src import config
from src.adaptation_label import apply_label
from src import honest_eval


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fast", action="store_true")
    args = ap.parse_args()

    df = pd.read_csv(config.DATA_PROCESSED / "historical_transfers.csv",
                     parse_dates=["transfer_date"])
    df = apply_label(df)
    print(f"transfers={len(df)}  positive rate={df['label'].mean():.3f}")

    preds, ts, paired, cv = honest_eval.run_all(
        df, config.TABLES_DIR, config.FIGURES_DIR,
        n_boot=500 if args.fast else 2000, n_repeats=3 if args.fast else 5,
        do_cv=not args.fast)

    pd.set_option("display.width", 200)
    show = ts[["model", "auc", "auc_lo", "auc_hi", "brier", "log_loss", "ece"]].round(3)
    print("\nTIME SPLIT (train <= 2023/24 -> test 2024/25), 95% bootstrap CI on AUC")
    print(show.to_string(index=False))
    print("\nPAIRED: AUC(model) - AUC(mv_only)")
    print(paired.round(3).to_string(index=False))
    if cv is not None:
        print("\nGROUPED CV (by player, non-temporal, secondary protocol)")
        print(cv.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
