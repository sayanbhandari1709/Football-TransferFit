# TRANSFERFIT Phase 0 patch
Copy over C:\Football\DATA\project (keeps config.py untouched):
  src/honest_eval.py        NEW  baselines, bootstrap CIs, paired tests, grouped CV, MLP ablation
  src/similarity.py         FIX  (1) pandas-3-safe dtype check, (2) train/test scaling mismatch in
                                 compute_peer_features, (3) 3 SIM_FEATURES lacked the "pre_" prefix
  scripts/run_honest_eval.py NEW
  scripts/train_evaluate.py FIX  no longer scores test rows with the all-data production model
  app/streamlit_app.py      FIX  validation tab shows honest table, not hard-coded claims
Then: python scripts/run_honest_eval.py   (add --fast for a quick run)
Retrain the artifact afterwards: python scripts/train_evaluate.py
